clear all; clc; close all 

CL = 0.8;

ResulrMat = [];
Res_cnt = 1;
FileList = dir;
FileList(1:2,:)=[];
FolderList
DirLstL_0 = DirName;

   
    a = cd;
    b = strcat(a,'\',DirLstL_0);
   
    FileList = dir(cell2mat(b));
    FileList(1:2,:)=[];
    FolderList
    DirLstL_1{1} = [b, DirName];


    
Lp_Dir_lst = DirLstL_1;
    for Lv = 1:7
DirLstL_Int = []; 

for Clp2 = 1:size(Lp_Dir_lst,1)
    for Lp2 = 2:length(Lp_Dir_lst{Clp2,1})
           DirName=[];
           d = strcat(Lp_Dir_lst{Clp2,1}(1),'\',Lp_Dir_lst{Clp2,1}(Lp2));
    
    FileList = dir(cell2mat(d))
    FileList(1:2,:)=[];
    
    
    
    FolderList
    
    if isempty(DirName)==1
    continue
    end
    
    DirLstL_trans{Lp2-1,1} = [d, DirName]
    end
    DirLstL_Int = [DirLstL_Int;DirLstL_trans];
    DirLstL_trans= [];
end
    
%===============  Step 2.1  ======================================= 

Lp_Dir_lst = DirLstL_Int;

    end

    ResulrMat
    