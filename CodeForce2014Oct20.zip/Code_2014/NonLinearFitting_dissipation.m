% Nonlinear parameter estimation and errors from Matlab.
% Introduction 
% 
% We needed to estimate a set of parameters and their errors for a nonlinear curve fit of cellular conductance data. The conductance was a function of voltage and was modeled as a Boltzmann term, an exponential term and a constant:: 
% 
% g = p3/(1+e((v-p1)/p2)) + p5*e((v-45)/p6) + p4 
% 
% Where g and v are the input data, with v is in millivolts, and p1-p6 are the desired parameters. 
% 
% A program was produced to: 
% 
% Fit data several times with randomly selected starting conditions to validate the fit and make sure the code was not falling into local minima. 
% Plot all of the curve fits and separate out the Boltmann and exponential terms. 
% Estimate the errors in the parameters as the greater of the multiple fit scatter and the formal propagated error. 
% List the parameters and a table of the Boltzmann and exponential term conductances. 
% The program 

%Program for Matt Gruhn
%Written by Bruce Land, BRL4@cornell.edu
%May 20, 2004
%===================
%curve fit of 6 parameter conductance function of voltage
%Formula from Matt:
%g=	(m3/((1+exp((m0-m1)/m2))^(1)))+(m4)+(m5*exp((m0-45)/m6)); 
%need to get parameters and their error range
%--Then separately plot the "boltzmann" and exponential parts separately
%===================

% clear all
% %total fit
% figure(1)
% clf
% %part fit
% figure(2)
% clf
% %parameter histograms
% figure(3)
% clf

%========================================================
%START settable inputs
%========================================================


%estimate of error in conductance measurement
%Currently set to 2%
y=Q_Energy_IU_q;
dy = y*CONFIDENCE_INTERVAL_FIT;
x=[CCC_1];    % 
	
%formula converted to
%The inline version
func = inline('p(1)*x(:,1)','p','x');   % +p(2)*x(:,2)



%To detect the sensitivity of the fit to starting parameter guess,
%the fit is run a number of times.
%each fit is plotted and each parameter plotted as a histogram
Nrepeat=20;
%each parameter is varied by a normal distribution with
%mean equal to the starting guess and std.dev. equal to
%sd*mean
sd = 0.3;
%histogram zoom factor (how many std dev to show)
zfactor = 2;
%parameter outlier cuttoff: lowest and highest N estimates are removed
outcut=10;
%========================================================
%END settable inputs
%========================================================
terms=1;
%list of all parameter outputs to use in histogram
pList=zeros(Nrepeat,terms);

for rep =1:Nrepeat
    %     rep
    
    %form the new randomized start vector
    p = [p0(1)*(1+sd*randn)];
    %do the fit
    [p,r,j] = nlinfit(x,y,func,p);
    %copy fit to list
    pList(rep,:) = p';
    
    %get parameter errors
    c95 = nlparci(p,r,j);
    [yp, ci] = nlpredci(func,x,p,r,j);
    
    %plot the fit 1 parameter only
	if Plot_process_quantification==1 
		figure (count_figures+76)
		hold on 
		box on
		title(' Energy NONLINEAR: FIT','fontsize',12)
		xlabel('A/A0','fontsize',14) 
		ylabel('Normalised  energy NONLINEAR: FIT','fontsize',14)
	
     	errorbar(Q_Amplitude_IU_q,func(p,x)*6.24e18,ci,ci,'b-');

		hold on

		errorbar(Q_Amplitude_IU_q,y*6.24e18,dy,dy,'ro')
	end
	
end
 

output_onefit=mean(pList);
output_onefit_std=std(pList);


%%%% DOOO!
if ((output_onefit>0)||(Plot_process_quantification==1))
	
	
	%%%%%%%%%%%%%%%%%%%%%%% PLOT Energies %%%%%%%%%%%%%%%%%%%%%
	
	if output(1)>0  % viscosity positive
	
	Energy_eta_nl = Constant_eta_2*output_onefit(1)*((Q_Amplitude_IU_q.^(0.5)).*(Q_Indentation_IU_q.^2));
	Energy_nl_total=Energy_eta_nl;
	
	Energy_nl_total_norm=Energy_nl_total*6.24e18/Edis_max_T;
	%Substract_norm_Energy=Q_Energy_IU(1)*6.24e18/Edis_max_T;
	
	Energy_eta_nl_norm=Energy_nl_total_norm;
	
	else
		
		Energy_surface_nl = Constant_delta_gamma_2*output_onefit(1).*Q_Indentation_IU_q;
		Energy_nl_total=Energy_surface_nl;
		Energy_nl_total_norm=Energy_nl_total*6.24e18/Edis_max_T;
		
		Energy_surface_nl_norm=Energy_nl_total_norm;
	end
	
	figure (count_figures+77) %% Plot energies a single parameter

	hold on
	box on
	if output(1)>0  % viscosity positive
		plot(Q_Amplitude_IU_q/A0, Energy_nl_total_norm, '.r','Markersize',M_size, 'displayname','Energy Dissipated viscoelasticity');
	else     %%% surface energy
		plot(Q_Amplitude_IU_q/A0,Energy_nl_total_norm , '.m','Markersize',M_size, 'displayname','Energy Dissipated surface energy');
	end
% 	plot(Q_Amplitude_IU_q/A0, Energy_nl_total_norm , '.k','Markersize',M_size, 'displayname','Energy Dissipated Total fit');
	%%%% Plot Total true fitted energy %%%%%
	plot(A_norm, Edis_norm_ss-Substract_norm_Energy,'.c','Markersize',M_size, 'displayname','Energy Dissipated Normalised:REPULSIVE: Smooth');  % smoo
	plot(A_norm, Edis_norm_ss,'.b','Markersize',M_size, 'displayname','Energy Dissipated Normalised:Smooth');  % smoo

	title(' Energy NONLINEAR (1 Parameter): FIT','fontsize',12)
	xlabel('A/A0','fontsize',14) 
	ylabel('Normalised  energy ANALYTIC: FIT','fontsize',14)
	
	if output(1)>0  % viscosity positive
		text(0.5,0.2, ['eta: ' num2str(output_onefit(1)), ' Pa s'],'fontsize',12);
		text(0.5,0.4, ['eta (std): ' num2str(output_onefit_std(1)), ' Pa s'],'fontsize',12)
		
	else
		text(0.5,0.2, ['Delta Gamma: ' num2str(output_onefit(1)) '  mJ/m2'],'fontsize',12);
		text(0.5,0.4, ['Delta Gamma (std): ' num2str(output_onefit_std(1)), ' mJ/m2 '],'fontsize',12)
	end
	
	axis([ min(A_norm)  1 0 1.4])
%%%%%%%%%%%  Calculating error Energy fit single parameter %%%%%%%%%
% 	Energy_true_norm=Q_Energy_IU_q*6.24e18/Edis_max_T;
	Differemce_squared_energy_nl_fit_single=(((Energy_true_norm(2:end)-Energy_nl_total_norm(2:end))/max(abs(Energy_true_norm))).^2);


	Data_input=Differemce_squared_energy_nl_fit_single;

	Chauvenete;
	Sum_squared_energy_nl_fit_single=sum(Data_input);
	energy_nl_fit_points_single=length(Data_input);

	Standard_deviation_error_energy_nl_fit_single=floor(sqrt(1/energy_nl_fit_points_single*(Sum_squared_energy_nl_fit_single))*100);

	text(min(A_norm),1, ['ERROR NL FIT (STD): ' num2str(Standard_deviation_error_energy_nl_fit_single), ' %'],'fontsize',15);
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	
	
	
	
%%%% End plot energies as function of amplitude
	
figure (count_figures+78)  %% STATS 
hold on 
box on
% %plot and print parameter table
fprintf('\r\rFit parameters and 95percent confidence range\r')
for i=1:terms
    subplot(terms,1,i)
    lowerLimit = mean(pList(:,i))-zfactor*std(pList(:,i));
    upperLimit = mean(pList(:,i))+zfactor*std(pList(:,i));
    hist(pList(:,i),linspace(lowerLimit,upperLimit,30))
    Limits(i,1)=lowerLimit
    Limits(i,2)=upperLimit
    %
    fprintf('%7.3f\t +/- %7.3f \r',...
		mean(pList(:,i)),...
        max(2*std(pList(:,i)),mean(pList(:,i))-c95(i,1)));
	
	xlabel('Pa s ','fontsize',14) 
	ylabel('Counts','fontsize',14)  
end

fprintf('\r\rFit parameters omitting outliers\r')
for i=1:terms
    %get rid of outliers
    pup = sort(pList(:,i));
    pup = pup(outcut:end-outcut);
    %print again
    fprintf('%7.3f\t +/- %7.3f \r',...
        mean(pup),...
        max(2*std(pup),mean(pup)-c95(i,1)));
    pbest(i)=mean(pup);
end


saveas(count_figures+77, num2str(77),'fig')
saveas(count_figures+78, num2str(78),'fig')

else  %% Everything negative 
	figure (count_figures+77)
	hold on
	box on
	text(0.5,0.5, ['RESULTS: ALL NEGATIVE NL FIT:'],'fontsize',12);
	axis([ 0  1 0 1.4])
	saveas(count_figures+77, num2str(77),'fig')	
end


if Plot_process_quantification==1 	
	saveas(count_figures+76, num2str(76),'fig')	
end



% Eaf = output(2)*;
% Eef = sqrt(2)/4*pi*R^0.5*omg*output(1)*(AmMRet(1:dd:length(ZcRet)-1)).^0.5.*(delI+T).^2;

