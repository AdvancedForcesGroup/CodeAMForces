clear all
clc
close all                     % closes all figures
format longEng


%%%% Plots:  

%% raw always  point and red
%% smooth always  point and blue
%% Single points are triangle and black
%%% etxra points cyane 

% ====================================================================================================================================================
% ===================== USER settings =========================================================================================================
% ====================================================================================================================================================


% k=42;                           % N/m
% Q=450;                          % Quality factor
% R = 8e-9;                       % tip radius [m]
% f0=305e3;
% 
k=69.73;                           % N/m
Q=532.6;                          % Quality factor
R = 8e-9;                       % tip radius [m]
f0=348355;
AmpInvOLS = 40;				%   %% Mica 10%RH 37.5; Mica 60% 40.2   % 80% RH 40.4   (mica Carlo 39-39.5) 36.8;% (Silicon) %42.5;   %% 36.8 nm/V for Silicon    %% nm/V; Useless if Pick_Amps = 1  For silicon Model some 37nm/volt required   41.5 for mica and 36.5 for the work
M_size=5;						% Marker size. 6 for FFT simulation 3 for continuous
set(0,'DefaultAxesFontSize',14)  %%% This sets the font size in figures
set(0,'DefaultAxesFontSize',14)  %% axis size figures
set(0,'DefaultAxesLinewidth',2)  %% Lne width figures
box on



Extension=1;                            % If 1 then it does extension otherwise with 0  retraction curve (experimental only) 
Smooth_raw_data=0;						%%% Smoothens the raw data. Requied 1 for experimental only  This slows down. Also requires to rearrange dmin from larger to smaller. 
Virial_Distances=1;						%%% Finds distances in virial
Percentage_Virial=0.05;					%%% This is where we want to start counting virial for figure 60
Attractive_Distances=1;					%% activates looking at distances of attractive forces figure 11
Attractive_min_force=0.2e-9;			%%% From the above, checks minimum force here to zero. figure 11
Damping_magnitude=0.1e-9;				%%% If Attractive_Distances activated then it checks at which distance (relative to zero) the damping starts to be larger than chosen  value
Error_Attractive_zero=0.1e-9;			%% This is the error to locate minimum in force
Bistable_curves=0;                      % If the curve shows bistability, then 1, otherwise with continuous transition 0 NOT DONE YET
Averaging_percentage_of_signal=0.05;    %% This is the percentage of avergaing for setting phase at 90, deflection at zero, etc. DEFAULT 0.1 
crop_initial_data=0;					%%% Allows you to crop both ends of initial data 
Limit_AmplitudeToA0=1;					%%% This limits amplitudes to A0, so there are no complex numbers for zc>>A0 due to thermal noise
Maximum_lenght_data_set=0;				%% If 1 it will chop data to the number especified below 
Maximum_lenght_data=5000;				% If a number is chosen the length of the vectors wil be between that and double that if 1 is chosen above 
use_real_Edis=1;						%%% If 1 it uses real Edis. Only valid for simualtion, otherwise zero. This only affects the analytical file 
FFT_Data=1;								%%% If FFT Data (typically simulation)  just leave to 1. If zero, it trims from the continuous curves on both sides 100
plot_data_processing_figures=1;			%%% If zero you do not see how the data is being prepared to be processed. Figs. 1-2 4-10 not shown
save_files_processing=1;				%%% This saves plotted figures. Not done yet				
save_files_further_analysis=1;			%% Viraial etc
save_files_Sader_Katan=1;		
save_files_Raman=0;

%%%%% Simulation data or experimental data  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Simulation=1;							%% If simulation=1 then the data is simulation, if 0 then experimental
Load_simulation_forces=1;				%% This loads simulation forces at the end if activated. Simulation also has to be active. 
eta_c=0;								%% This is for viscoelastic models but it is deactivated now
a0=0.165e-9;							%% This is for viscoelastic models but it is deactivated now

%%%%%%%%% Solution Method %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%% Raman's solution parameters %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Sader_Katan=1;				%%% Solves by Katan and Sader method
Raman=0;					%%% Solves by Raman method 
Further_Analysis=1;			%%% This gets analytical stuff like virial and energy dissipation 

omg_f0 = 2*pi*f0 ;                  % Angular frequency  natural Omega [rad/s]
omg_drive=omg_f0;

gamma_medium=k/omg_f0/Q;
                                      
			
%%%% More details to choose ==========================================================================================%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Number_of_Bistable_jumps=1;           % NOT IMPLEMENTED YET. Default 1 if there is only one jump. There might be two. 
Sorting_zc_larger_to_smaller=0;         % DEFAULT 0. If 1, then it forces zc to always decrease, i.e. drift removal, if 0, it does not do it, i.e. drift present, complex numbers might result. 
Removing_repeat_zc=0;                   % Default 0. IMPORTANT. Sorting Zc required for this to work. Otherwise it removes many points. if 1 then it removes repeated zc.
%Sorting_zc_larger_to_smaller_dmin=0;    % NOT IMPLEMENTED Default 0, this forces the values dmin to decrease in the vector d_min, if zero, figure 10 (conservative force) might be very noisy
plot_raw_curves=1;						% If 1 it plots raw curves, deflection, amplitude and phase
Use_smoothening=0;                      % THIS SMOOTHENING MIGHT GIVE PROBLMES. Smoothens data to be processed. I.E. The computed data is first smoothende. if 1 then it will use smoothening also, otherwise with 0 it wont  

%%%%%==================================================================================================================================== %%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%% Experimental loading detail ====================================================================================%%%%%%%%%%%%%%%%%%%%%%%%%%%									  
% Columns order: 2 Zs [m], 2 Amplitudes [V], 2 Phases [o] and 2 Delfs [V]
%(each has extend and retracrt) 

%%% Carlo December data %%%
ZEx =1 ; DfEx =3; ZRet = 4;  DfRet = 6; AEx =7 ;  ARet =8 ; PEx =9 ;  PRet =10;

%%%% standard %%%%
%ZEx =1 ; DfEx =2 ; ZRet = 3;  DfRet = 4; AEx =5 ;  ARet =6 ; PEx =7 ;  PRet =8 ;

%%%%%%%%%%%%%%%% END Experimental loading====================================================================================%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%% Simulation loading detail ====================================================================================%%%%%%%%%%%%%%%%%%%%%%%%%%

if Simulation==1 % Simulation data load
	%%%% SimZc=1;  SimAm=2; SimPh=3; SimDf=4; SimApeak=5;  SimPhpeak=6;	%% This is how the data is in the original simulation file	
	ZEx=1;  AEx=2; PEx=3;  DfEx=4; E_T=5;
	rrr=5;    % number of column vectors in file  %% Typically 20 for nomrmal files. Short files 8. FFT ZZc, Amp Phase Def Energy is 5
end



%%%%%%%%%%%%%%%% Simulation loading detail ====================================================================================%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%% END loading details ====================================================================================%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%========= Smoothening coefficients    ==============================================================================================%%%%

  %%% Stuf with single s implies smoothening data to be processed. Double ss is for the smoothening that accurs after processing all raw data

  ss_Fts_cons_S_K=0.02;   %% This is Katan Sader conservative. Smoothens the final coefficient. This works fine and should be enabled for experimental data (also used in simulation)
  ss_Damping_Coeff=0.015;  %% Smoothens the final coefficient. This works fine and should be enabled for experimental data
  s_defl=0.1;
  s_d_min=0.01;
  s_d_min_Incr=0.01;    %%% smooth dmin incre when dmin is not previously smoothened
  s_Omega_AM=0.003;
  s_Omega_Incr=0.001;
  s_F_dis=0.01;
  s_Fts_cons_s=0.015;       %% Smoothens the final conservative with rloess
  s_Fts_dis_s=0.04;
  s_Virial=0.04;
  %%% Only Simulation below %%
  s_Edis=0.01;				%%% Typically for simulation of very smooth experimental data 
  Derivative_points_sim=1;  %%% Points to calculate derivative of energy 		
  s_Damping_Coeff=0.008;
  s_Derivative=0.08;
  s_Derivative_A=0.08;
  s_Derivative_A_A_crop=0.08;
  s_Derivative_A_A=0.08;
  s_Derivative_Edis=0.06;

 MultiplierError=1;  
% ====================================================================================================================================================
% ===================== end of user settings =========================================================================================================
% ====================================================================================================================================================



[filename, pathname,filterindex] = uigetfile({'*.txt'},'File Selector');
if isequal(filename,0)
return
elseif isequal(filterindex,1)
    DtAq=load ([pathname,'\',filename]);
end
%%

count_figures=0;

if Simulation==0 % Experimental data load
	rrr=10;   % Carlo 
	%rrr=8;    % Standard 
end


length_vectors=size(DtAq,2);

for ccc=1:rrr:length_vectors
	
	if Simulation==0					% Experimental data load------------------------------------------------------------------------------

		set_d=DtAq(:,ccc:ccc+rrr-1);
	end
	
	if Simulation==1
		
		Extension=1;					% Simulation data load. Always extension only ------------------------------------------------------
		set_d=DtAq(:,ccc:ccc+rrr-1);
 
	end
	
	%% ======================COLLECT curves =================================================================================== %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   
	Collect_curves_file;   % collects curves Experimental and simulation 

	%%%%%%%%%========= END COLLECT CURVES   ====================================================================================%%%%%%%%%%%%%%%%%%%%%%%%%


	%%==============Sorting zc cantilever separation from large to small not changing order of elements, i.e. raw data===========%%%%%%%%%%%%%%%%%%%
  
    Sorting_zc_cantilever_separation;    % this will force first element zc in vector to be zc>>A0 and last Zc<<A0 no change in data
	
	%%------------------ END CANTILEVER SEPARATION ORDER, i.e. raw data ===========================================================%%%%%%%%%%%%%%%%%%%
    
	%%%%%  Amax and deflection in nm ==========================================================================================%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 
	if Simulation==0		% Experimental only since simulation is in nm
		AmEx=AmEx*AmpInvOLS*1e-9;
		DflEx=DflEx*AmpInvOLS*1e-9/1.09;
	end
	%%% IMPORTANT, from here on Amplitude and deflection are in nm ====================================================%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	
	
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	
	%%%%% ================ Ploting dmin =======================================================================%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	if plot_raw_curves==1
		figure (count_figures+86) 
		plot(ZsnrEx, ZsnrEx-AmEx, '.k', 'Markersize',3, 'displayname','D_min');
		title(' Dmin versus zc: raw','fontsize',12)
		xlabel('Zc','fontsize',14) 
		ylabel('dmin','fontsize',14)
	end
	%%%%% ================ END Ploting dmin RAW =======================================================================%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Preparing DATA %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	
	
	%%%% remove first and last part of vectors ============================================================================================ %%%%%%%%%%%%%%%
	if FFT_Data==0
	if Simulation==1
		Set_remove=[ZsnrEx, AmEx, PhEx, DflEx, Edis_T];
		Set_remove=Set_remove(100:end-100,:);   %% Because begining and end might induce errors %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
		ZsnrEx=Set_remove(:,1);
		AmEx=Set_remove(:,2);
		PhEx=Set_remove(:,3);
		DflEx=Set_remove(:,4);
		Edis_T=Set_remove(:,5);
	else
		Set_remove=[ZsnrEx, AmEx, PhEx, DflEx];
		Set_remove=Set_remove(40:end-40,:);   %% Because begining and end might induce errors %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
		ZsnrEx=Set_remove(:,1);
		AmEx=Set_remove(:,2);
		PhEx=Set_remove(:,3);
		DflEx=Set_remove(:,4);
	end
	end
	
	%%%%%% Allow to crop curve %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	
	if crop_initial_data==1
		
	figure (90)
	plot(ZsnrEx,AmEx, '.k', 'Markersize',M_size, 'displayname','Amplitud A'); 
	hold on
	[x1,y1]=ginput(2);

	Pck_ini=[x1 , y1];
	Pck_ini=sort(Pck_ini,1); 
		

	for ii=1:1:2
            
		Zc_values_ini(ii,1)=Pck_ini(ii,1); 
		Minimum_pick_ini(ii,1)=Pck_ini(ii,2);
        plot(Zc_values_ini(ii,1),  Minimum_pick_ini(ii,1),'Vk', 'Markersize',5)    
        Minimum_error_dumb_ini=MultiplierError*min(abs(ZsnrEx-Zc_values_ini(ii,1)));
        Minimum_error_ini(ii,1)=Minimum_error_dumb_ini;
        
        Position_Zc_dumb_ini=find(abs(ZsnrEx-Zc_values_ini(ii,1))<=abs(Minimum_error_dumb_ini),1, 'last');
        Position_Zc_ini(ii,1)=Position_Zc_dumb_ini; % this is the position of the vector element
        Zc_found_ini(ii,1)=ZsnrEx(Position_Zc_dumb_ini);
		plot(Zc_found_ini(ii,1),  AmEx(Position_Zc_dumb_ini),'Vk', 'Markersize',5)
	end  
	
	if Simulation==0
		
		Set_to_crop=[ZsnrEx, AmEx, PhEx, DflEx];
		Set_to_crop=Set_to_crop(Position_Zc_ini(2,1):Position_Zc_ini(1,1),:);
		
		ZsnrEx=Set_to_crop(:,1);
		AmEx=Set_to_crop(:,2);
		PhEx=Set_to_crop(:,3);
		DflEx=Set_to_crop(:,4);
		
	else
		Set_to_crop=[ZsnrEx, AmEx, PhEx, DflEx, Edis_T];
		Set_to_crop=Set_to_crop(Position_Zc_ini(1,1):Position_Zc_ini(2,1),:);
		
		ZsnrEx=Set_to_crop(:,1);
		AmEx=Set_to_crop(:,2);
		PhEx=Set_to_crop(:,3);
		DflEx=Set_to_crop(:,4);
		Edis_T=Set_to_crop(:,5);
	end
	
	end	

	
	%%%% End remove first and last part of vectors ============================================================================= %%%%%%%%%%%%%%%
	

	
	%%%% ============ Sorting zc values (OPTIONAL) from larger to smaller ==========================================================%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
    
    if Sorting_zc_larger_to_smaller==1    %% This activated might induce errors
        Sorting_zc_larger_to_smaller_file;
    end
    
    if Removing_repeat_zc==1  %  might induce errors due to lack of data points, in particular if they are not sorted from large to small zc
		Removing_repeat_zc_file;
            
    end  %% end of removing same Zc-------------------------------------------------------------------------------------------------------%%
        
	%%%%%%%%%% end sorting zc and/or removing zc ================================================================================== %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
	if Simulation==0
		ZsnrEx =ZsnrEx-ZsnrEx(end);   %% last zc is zero 
	end
	
	%%%%%%%%%%%%%% PLOT amplitude, deflection and phase %%%%%%%%%%%%%%%%%%%%%%%%%%
	close (count_figures+1)
	if plot_data_processing_figures==1
		figure (count_figures+1)
		plot(ZsnrEx,AmEx, '.k', 'Markersize',M_size, 'displayname','Amplitud A');    %%% 'fontsize',14,  ,  , 

		hold on
		title(' Amplitud and deflection versus zc','fontsize',12)
		xlabel('Zc','fontsize',14) 
		ylabel('Amplitude','fontsize',14)
	
		plot(ZsnrEx,DflEx, '.c', 'Markersize',M_size,'displayname','Amplitud A');
	
	end
	
	%%%%%%%%%%%%% Conservative branch phase  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%A0 = mean(AmEx(floor(0.02*length(AmEx)):floor(0.1*length(AmEx))));
	A0 = mean(AmEx(1:floor(0.03*length(AmEx))));
	AmEx_dummy=AmEx;
	ANGLE_CONSERVATIVE=zeros(length(PhEx),1);
	trial=zeros(length(PhEx),1);
 	for iii=1:length(PhEx)
		
		if AmEx_dummy(iii, 1)>A0
			AmEx_dummy(iii, 1)=A0;
			%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% LIMITING MAXIMUM AMPLITUDES TO A0 GETS RID OF COMPLEX %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
			%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
			
			if Limit_AmplitudeToA0==1
				AmEx(iii,1)=A0;
			end
		
		end
	end	
	
	for iii=1:length(PhEx)
		trial(iii,1)=asin(AmEx_dummy(iii, 1)/A0);
		ANGLE_CONSERVATIVE(iii, 1)=trial(iii, 1)*180/pi;
		if PhEx(iii,1)>90
			ANGLE_CONSERVATIVE(iii, 1)=180-ANGLE_CONSERVATIVE(iii, 1);
		end
	end


  %%%%%%%%%%% Phase in zc %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	if plot_data_processing_figures==1
		figure (count_figures+2)
		plot(ZsnrEx,PhEx, '.r', 'Markersize',M_size, 'displayname','Phase degrees');
		box on
		hold on
		plot(ZsnrEx,ANGLE_CONSERVATIVE, '.b', 'Markersize',M_size, 'displayname','Phase Conservative');
		title(' Phase versus zc','fontsize',12)
		xlabel('Zc','fontsize',14) 
		ylabel('Phase','fontsize',14)
	end
	

	
   %%%%%%%%%================================================================================================================================= %%%%%%%%%%%%%%%%%%%%%%%
   %%%%%%%%%===================================START DATA PROCESS ====================================================================%%%%%%%%%%%%%%%%%%%%%%%%
   %%%%%%%%%=================================================================================================================================%%%%%%%%%%%%%%%
    
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%% Differentiate between monostable and bistable %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%----------------The following section crops data "dmin" in bistable region if 1-------------------------------------------------------%%%%%%%%%%
    
%     if Bistable_curves==1 %% default 0, If 1, then it will ask you to chose 
    
%         Set_crop_Bistable=[ZsnrEx, AmEx, PhEx, DflEx];
%         
%         figure (count_figures+87)
%         plot(Set_crop_Bistable(:,1),Set_crop_Bistable(:,2));
%         zoom on
%         pause 
%            
%         [xx1,yy1]=ginput(2);
% 
%         Pck_xx=[xx1 , yy1];
%         Pck_xx=sort(Pck_xx,1,'descend');
%         
%         %%% finding elements to crop
%         figure (count_figures+88)
%         plot(Set_crop_Bistable(:,1),Set_crop_Bistable(:,2));
%         hold on
%         for ii=1:1:2
%             
%             Zc_values_Bistable(ii,1)=Pck_xx(ii,1); 
%             Amplitude_pick_Bistable(ii,1)=Pck_xx(ii,2);
%             plot(Zc_values_Bistable(ii,1),  Amplitude_pick_Bistable(ii,1),'Vk', 'Markersize', 5);   %%% 'linewidth',3)    
%             Minimum_error_dumb_Bistable=MultiplierError*min(abs(Set_crop_Bistable(:,1)-Zc_values_Bistable(ii,1)));
%             Minimum_error_Bistable(ii,1)=Minimum_error_dumb_Bistable;
%         
%             Position_Zc_dumb_Bistable=find(abs(Set_crop_Bistable(:,1)-Zc_values_Bistable(ii,1))<=abs(Minimum_error_dumb_Bistable),1, 'last');
%             Position_Zc_Bistable(ii,1)=Position_Zc_dumb_Bistable; % this is the position of the vector element
%             Zc_found_Bistable(ii,1)=Set_crop_Bistable(Position_Zc_dumb_Bistable,1);
%             plot(Set_crop_Bistable(Position_Zc_dumb_Bistable,1),  Set_crop_Bistable(Position_Zc_dumb_Bistable,2),'Vk', 'Markersize', 5)
%                 
%         end  
%         
%         
%         %%%%%%%%%%%% ---------- Here I crop the bistable region ------%%%%
%         Set_crop_Bistable_dumb1=Set_crop_Bistable(1:Position_Zc_Bistable(1,1), :);
%         Set_crop_Bistable_dumb2=Set_crop_Bistable(Position_Zc_Bistable(2,1):end,:);
%         
%         Initial_Set_save=Set_crop_Bistable;  % I save the initial set for future possible use
%         
%         %%%% Croped matrix %%%%%%%%%%
%         ZsnrEx1=Set_crop_Bistable_dumb1(:,1);
%         ZsnrEx2=Set_crop_Bistable_dumb2(:,1);
%         
%         AmEx1=Set_crop_Bistable_dumb1(:,2);
%         AmEx2=Set_crop_Bistable_dumb2(:,2);
%         
%         PhEx1=Set_crop_Bistable_dumb1(:,3);
%         PhEx2=Set_crop_Bistable_dumb2(:,3);
%         
%         DflEx1=Set_crop_Bistable_dumb1(:,4);
%         DflEx2=Set_crop_Bistable_dumb2(:,4);
%         
%         %%%% Put together matrices %%%%%% Maybe not useful if bistability 
%         
%         Set_crop_Bistable=[Set_crop_Bistable_dumb1;Set_crop_Bistable_dumb2];
%         
%         ZsnrEx=Set_crop_Bistable(:,1);
%         AmEx=Set_crop_Bistable(:,2);
%         PhEx=Set_crop_Bistable(:,3);
%         DflEx=Set_crop_Bistable(:,4);
%         
%         %%%%%
%         figure (count_figures+88) 
%         plot(ZsnrEx,AmEx, '.r','Markersize',2);
% 	end
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%% The above is for bistable curves and it removes jumps data ===========================================%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%  ---------------------- End of cutting Bistable region -----------------------------------------------------------------%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   %%%%%%%%%%%%%%%  Here the distinction between bistable curves and monostable starts %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   
	 
    if Bistable_curves==1  % Bistable 
        
%         d_min1=ZsnrEx1-AmEx_m1;
%         d_min2=ZsnrEx2-AmEx_m2;
%         
%         d_min_Smth1= smooth(d_min1,s_d_min,'rloess');
%         d_min_Smth2= smooth(d_min2,s_d_min,'rloess');
%         
%         d_min_Incr1=d_min1(2:end)-d_min1(1:end-1);
%         d_min_Incr2=d_min2(2:end)-d_min2(1:end-1);
%         
%         d_min_Incr_Smth1= smooth(d_min_Incr1,s_d_min_Incr,'rloess');
%         d_min_Incr_Smth2= smooth(d_min_Incr2,s_d_min_Incr,'rloess');
%         
%         %%%% Below, first smoothed dmin, then increment dmin
%         d_min_Smth_Incr1=d_min_Smth1(2:end)-d_min_Smth1(1:end-1);
%         d_min_Smth_Incr2=d_min_Smth2(2:end)-d_min_Smth2(1:end-1);
%         
%         %%% plot dmin
%         figure (count_figures+3)
%         hold on
%         plot(ZsnrEx1, d_min1, '.r','Markersize',2);  %% point 
%         plot(ZsnrEx2, d_min2, '.r','Markersize',2);
%         plot(ZsnrEx1, d_min_Smth1, '.b','Markersize',2);
%         plot(ZsnrEx2, d_min_Smth2, '.b','Markersize',2);
%         %%%% Plotting minimum in separation %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%         find_minimum_delta=min(d_min_Smth2);
%         element_find_minimum_delta=find((d_min_Smth2)==find_minimum_delta);
%         plot(ZsnrEx2(element_find_minimum_delta),  d_min_Smth2(element_find_minimum_delta),'Vk', 'Markersize',5)  %%% Plots minimum value found  in dmin
%         
%         %%%%%%% Picking range to plot %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%     
%         [x1,y1]=ginput(4);
% 
%         Pck=[x1 , y1];
%         Pck=sort(Pck,1);   
        
    else   %% Monostable 
		
		
			
		d_min=ZsnrEx-AmEx;     %%%%%%%  d_min defined raw ====================================
        d_min_Smth= smooth(d_min,s_d_min,'rloess');
        d_min_Incr=d_min(2:end)-d_min(1:end-1);
        d_min_Incr_Smth= smooth(d_min_Incr,s_d_min_Incr,'rloess');
        
        %%% plot dmin  ====================================================================================%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        figure (count_figures+3)
        hold on
        plot(ZsnrEx, d_min, '.r','Markersize',M_size, 'displayname','Dmin');
		hold on
		box on
		title(' Dmin versus zc','fontsize',12)
		xlabel('Zc','fontsize',14) 
		ylabel('Dmin','fontsize',14)
        plot(ZsnrEx, d_min_Smth, '.b','Markersize',M_size);
    
		%%% END plot dmin  ====================================================================================%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
		
		%%%% Finding and plotting minimum point in separation  ============================================================================= %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
		find_minimum_delta=min(d_min_Smth);
        element_find_minimum_delta=find((d_min_Smth)==find_minimum_delta);
        plot(ZsnrEx(element_find_minimum_delta),  d_min_Smth(element_find_minimum_delta),'Vk', 'Markersize',8)  %%% Plots minimum value found  in dmin
        text(0.7*max(ZsnrEx),0.8*min(d_min_Smth), ['Min Dmin:' num2str(d_min_Smth(element_find_minimum_delta))],'fontsize',12)
		   
		
		%%%%   END Finding and plotting minimum point in separation  ========================================================================%%%%%%%%%%%%%%%%
        
        %%%%%%% Picking range to plot %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
		if FFT_Data==0   %% Only if data is not from FFT	
			[x1,y1]=ginput(2);

			Pck=[x1 , y1];
			Pck=sort(Pck,1); 
		end     %%% End of if for FFT data 
        
	end  %% End of picking points to crop 
    
   
   %%%%%%%%%%%%%%%% Cropping section for dmin =========================================%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%-
   
   %%%%%%%%%%%%% BISTABLE NOT DONE FROM HERE DOWNWARDS %%%%%%%%%=====================================================%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   %%% ADD  if bistable_curve==0 from here onwards NOT DONE then move to Ramans code. %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   
   %%% finding elements to crop ===============================================================================================================%%%%%
   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   
	if FFT_Data==0   %% only if data is not from FFT     
		for ii=1:1:2
            
		Zc_values(ii,1)=Pck(ii,1); 
		Minimum_pick(ii,1)=Pck(ii,2);
        plot(Zc_values(ii,1),  Minimum_pick(ii,1),'Vk', 'Markersize',5)    
        Minimum_error_dumb=MultiplierError*min(abs(ZsnrEx-Zc_values(ii,1)));
        Minimum_error(ii,1)=Minimum_error_dumb;
        
        Position_Zc_dumb=find(abs(ZsnrEx-Zc_values(ii,1))<=abs(Minimum_error_dumb),1, 'last');
        Position_Zc(ii,1)=Position_Zc_dumb; % this is the position of the vector element
        Zc_found(ii,1)=ZsnrEx(Position_Zc_dumb);
        plot(Zc_found(ii,1),  d_min_Smth(Position_Zc_dumb),'Vk', 'Markersize',5)
                             
		end  
	else
		Position_Zc(1,1)=length(ZsnrEx)-1;
		Position_Zc(2,1)=2;
	end

   %%%%%%%%%%%%%  end looking for cropping elements =========================================================================================%%%%%%
	
   %%%%% plot increment deltamin  ====================================================================================================%%%%%%%%%%%%%
	if plot_data_processing_figures==1
		
		figure (count_figures+4)
		hold on
		plot(ZsnrEx(1:end-1),  d_min_Incr, '.r','Markersize',M_size, 'displayname','Increment Dmin');
		hold on
		box on
		title(' Increment Dmin versus zc','fontsize',12)
		xlabel('Zc','fontsize',14) 
		ylabel('Increment Dmin','fontsize',14)
		plot(ZsnrEx(1:end-1),  d_min_Incr_Smth, '.b','Markersize',M_size);    %% less smoothened but tracks   BEST USED
	end
	
   %%%%% END plot increment deltamin  =====================================================================================================%%%%%%%%%%%%%
   
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%=================== Resonance frequency AM ============================================================%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	
	cosine_angle_EX=cos(PhEx*pi/180);
	sine_angle_EX=sin(PhEx*pi/180);
	
	if plot_data_processing_figures==1
		figure (count_figures+5)
		hold on
		plot(ZsnrEx,cosine_angle_EX,'.r','Markersize',M_size, 'displayname','cosine angle');
		hold on
		box on
		title(' Cosine and Sine versus zc','fontsize',12)
		xlabel('Zc','fontsize',14) 
		ylabel('Cosine and Sine','fontsize',14)
	
		plot(ZsnrEx,sine_angle_EX, '.k','Markersize',M_size); 
	end
    
    %%%%%% ======================================drive amplitude =========================================================================%%%%
    
    
   % A0 = mean(AmEx(1:floor(0.05*length(AmEx))));    
    A_DRIVE=(A0/omg_f0^(2))*((omg_f0^(2)-omg_drive^(2))^(2)+(omg_f0^(2)*omg_drive^(2)/Q^(2)))^(1/2); 
    Amplitude_DriveRatio_Ex=A_DRIVE./AmEx;
    
	%%%%%%%%   RESONANCE FREQUENCY ================================================================================================%%%%%%%%%%%%%%
    
    OMEGA=omg_drive/omg_f0; %% normalised natural frequency
	OMEGA_sqr=OMEGA*OMEGA;
    OMEGA_AM=(OMEGA_sqr+Amplitude_DriveRatio_Ex.*cosine_angle_EX).^(0.5)-1;  %% True resonance frequency shift 
	if plot_data_processing_figures==1
		figure (count_figures+6)
		hold on
		plot(ZsnrEx,  OMEGA_AM, '.r','Markersize',M_size, 'displayname','Normalised frequency shift');
		hold on
		box on
		title('Normalised frequency shift versus zc','fontsize',12)
		xlabel('Zc','fontsize',14) 
		ylabel('Normalised frequency shift','fontsize',14);       %%% from non smoothened    BEST
		text(0.7*max(ZsnrEx),0.2*max(OMEGA_AM), ['Nat. Freq. :' num2str(f0) '  Hz '],'fontsize',12)
	end
    %%%========== increment Omega AM================================================================================================= %%%%
    
    OMEGA_AM_Dif=OMEGA_AM(2:end)-OMEGA_AM(1:end-1);
	
	if plot_data_processing_figures==1
		figure (count_figures+7)
		hold on
		box on
		plot(ZsnrEx(1:end-1),  OMEGA_AM_Dif, '.r','Markersize',M_size, 'displayname','Normalised frequency shift differential');
		hold on
		title('Normalised frequency shift differential versus zc','fontsize',12)
		xlabel('Zc','fontsize',14) 
		ylabel('Normalised frequency shift differential','fontsize',14); 
	end
	
	%%%%%%%%%%%%% SMOOTHING OMEGA AM =============================================================================%%%%%%%%%%%%%%%%%%%%%%%%%%
	if Use_smoothening==1
		figure (count_figures+6)
		hold on
		OMEGA_AM_Smth= smooth(OMEGA_AM,s_Omega_AM,'rloess');
		plot(ZsnrEx,  OMEGA_AM_Smth, '.b','Markersize',M_size);  %%% 
		figure (count_figures+7)
		hold on
		OMEGA_AM_Dif_Smth= smooth(OMEGA_AM_Dif,s_Omega_Incr,'rlowess');
		plot(ZsnrEx(1:end-1),  OMEGA_AM_Dif_Smth, '.b','Markersize',M_size);   %%% Best 
			
	end
	%%%========== END increment Omega AM================================================================================================= %%%%
    %%%%%%%%%%%%=================== END Resonance frequency AM ============================================================%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	
	
	%%%%%%%%%%%%=================== Dissipative term Fi for Intergral form of Sader-Katan ============================================================%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    Constant_Fi=Q*OMEGA;
	%%%%%
    Fi_Dis=-OMEGA_AM.*(Constant_Fi*Amplitude_DriveRatio_Ex.*sine_angle_EX-1);  %% This is the dissipation coefficient 
    %% Increments 
    Fi_Dis_Incr=Fi_Dis(2:end)-Fi_Dis(1:end-1);              %%% VERY NOISY
    
    %%% Plot F_dis=============================================================================================== %%%%%
    if plot_data_processing_figures==1
		figure  (count_figures+8)
		hold on
		box on
		plot(ZsnrEx,Fi_Dis,'.r','Markersize',M_size, 'displayname','Fi dissipation Sader');
		hold on
		title('Fi dissipation Sader versus zc','fontsize',12)
		xlabel('Zc','fontsize',14) 
		ylabel('Fi dissipation Sader','fontsize',14);  
    %%% Plot F_dis increment ===================================================================================%%%%%%%%%%
	
		figure  (count_figures+9)
		plot(ZsnrEx(1:end-1),Fi_Dis_Incr,'.r','Markersize',M_size, 'displayname','Fi dissipation differential Sader');
		hold on
		box on
		title('Fi dissipation differential Sader  versus zc','fontsize',12)
		xlabel('Zc','fontsize',14) 
		ylabel('Fi dissipation differential Sader','fontsize',14); 
	end
	
	if Use_smoothening==1
		Fi_Dis_Smth=smooth(Fi_Dis,s_F_dis,'rloess');  %% this makes processing slow , you can comment out
		Fi_Dis_Incr_Smth=smooth(Fi_Dis_Incr,s_F_dis,'rloess');  %%
		figure  (count_figures+8)
		hold on
		plot(ZsnrEx,Fi_Dis_Smth, '.b','Markersize',M_size); 
		figure  (count_figures+9)
		hold on
		plot(ZsnrEx(1:end-1),Fi_Dis_Incr_Smth, '.b','Markersize',M_size); 
	end
	
    %%%%%%%  Damping coefficient Raman and Sadar-Katan --------------------------------------------------------------------------------- %%%%%%%
    
    Damping_coefficient=gamma_medium*(A0./AmEx.*sine_angle_EX-1);
	
	if plot_data_processing_figures==1
		figure (count_figures+10)
		hold on
		box on
		plot(ZsnrEx, Damping_coefficient,'.r','Markersize',M_size,'displayname','Damping');
		title(' Damping effective coefficient versus zc','fontsize',12)
		xlabel('Zc','fontsize',14) 
		ylabel('Damping effective coefficient','fontsize',14); 
	end
	
	
	%%%% Dissipation coeficcient crop %%%%
    Damping_coefficient_crop=Damping_coefficient(Position_Zc(2,1):Position_Zc(1,1));
	
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%=================== CROPED SECTION STARTS BELOW ============================================================%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	

	
	ZsnrEx_crop=ZsnrEx(Position_Zc(2,1):Position_Zc(1,1));
	AmEx_crop=AmEx(Position_Zc(2,1):Position_Zc(1,1));		
	AmEx_mean_crop=(AmEx_crop(1:end-1)+AmEx_crop(2:end))/2;
    cosine_angle_EX_crop=cosine_angle_EX(Position_Zc(2,1):Position_Zc(1,1));
	sine_angle_EX_crop=sine_angle_EX(Position_Zc(2,1):Position_Zc(1,1));
	
	d_min_crop=d_min(Position_Zc(2,1):Position_Zc(1,1));				% This is the raw data for dmin
    d_min_Smth_crop=d_min_Smth(Position_Zc(2,1):Position_Zc(1,1));      % This one can be chosen rather than the top to smoothen dmin  
    d_min_Incr_crop=d_min_Incr(Position_Zc(2,1):Position_Zc(1,1));     %%% This is the raw data for dmin Incr
    
	d_min_mean_crop=(d_min_crop(1:end-1)+d_min_crop(2:end))/2;         %% mean value for integration  
	
	if Use_smoothening==1
        d_min_Incr_Smth_crop=d_min_Incr_Smth(Position_Zc(2,1):Position_Zc(1,1));      
		d_min_Smth_mean_crop=(d_min_Smth_crop(1:end-1)+d_min_Smth_crop(2:end))/2;  %%  %% mean value for integration
	end
		
	
    OMEGA_AM_crop=OMEGA_AM(Position_Zc(2,1):Position_Zc(1,1));
    %OMEGA_AM_crop=OMEGA_AM_Smth(Position_Zc(2,1):Position_Zc(1,1));
	OMEGA_AM_mean_crop=(OMEGA_AM_crop(1:end-1)+ OMEGA_AM_crop(2:end))/2;
	
    OMEGA_AM_Dif_crop=OMEGA_AM_Dif(Position_Zc(2,1):Position_Zc(1,1));  % raw data
    if Use_smoothening==1
        OMEGA_AM_Dif_Smth_crop=OMEGA_AM_Dif_Smth(Position_Zc(2,1):Position_Zc(1,1));
	end
	
	%%%%%%%%%%%%%%%%%% Saving the files related to processing %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	
	if save_files_processing==1    %% save files automatically
		for iii=1:10
		saveas(count_figures+iii, num2str(iii),'fig')	
		end
	end
	
	
	%%%%%%%%%%%%%%%%%% Sorting out dmin from large to small for processing%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	
		
	
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%=================== SOLVE EQUATION BELOW KATAN SADER OR RAMAN ============================================================%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	
	if Sader_Katan==1			%% This is the Sader-Katan method
		
		
		%%%%%%%%%%%%%%%%%%%%%%%% SADER KATAN DEFINITION PARAMETERS %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
		%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
		%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
		%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
		Fts_cons_crop_Smth=zeros(length(ZsnrEx_crop),1);			%% This is smoothened
		Fts_cons_crop_raw=zeros(length(ZsnrEx_crop),1);
		Integral_Fts_dis_crop_Smth=zeros(length(ZsnrEx_crop),1);	%% this is smoothened
		Integral_Fts_dis_crop_raw=zeros(length(ZsnrEx_crop),1);
    
    %%% raw %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
		I_1_crop_raw=zeros(length(ZsnrEx_crop),1);
		I_2_crop_raw=zeros(length(ZsnrEx_crop),1);
		I_1_dis_crop_raw=zeros(length(ZsnrEx_crop),1);
		I_2_dis_crop_raw=zeros(length(ZsnrEx_crop),1);
    %% smoothened
		I_1_crop_Smth=zeros(length(ZsnrEx_crop),1);
		I_2_crop_Smth=zeros(length(ZsnrEx_crop),1);
		I_1_dis_crop_Smth=zeros(length(ZsnrEx_crop),1);
		I_2_dis_crop_Smth=zeros(length(ZsnrEx_crop),1);

    %%%% Dissipation %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

		Fi_Dis_crop=Fi_Dis(Position_Zc(2,1):Position_Zc(1,1));
		Fi_Dis_Incr_crop=Fi_Dis_Incr(Position_Zc(2,1):Position_Zc(1,1));   % This is raw
		Fi_Dis_mean_crop=(Fi_Dis_crop(1:end-1)+Fi_Dis_crop(2:end))/2;
	
		if Use_smoothening==1
			Fi_Dis_Smth_crop=Fi_Dis_Smth(Position_Zc(2,1):Position_Zc(1,1));
			Fi_Dis_mean_Smth_crop=(Fi_Dis_Smth_crop(1:end-1)+Fi_Dis_Smth_crop(2:end))/2;
			Fi_Dis_Incr_Smth_crop=Fi_Dis_Incr_Smth(Position_Zc(2,1):Position_Zc(1,1));
		end 	
		
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% SADER-KATAN PARAMETERS FORCE%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% BELOW SOLVES EQUATION SADER KATAN %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	
	
	 for iii=1:1:length(ZsnrEx_crop)-1
        for ppp=1:1:iii
            
            if Use_smoothening==1   %% this is smoothended
                I_1_crop_Smth(ppp,1)=(1+(AmEx_mean_crop(ppp,1))^(0.5)/8/(sqrt(pi*(d_min_Smth_mean_crop(ppp,1)-d_min_Smth_crop (iii+1,1)))))*OMEGA_AM_mean_crop(ppp,1)*d_min_Incr_Smth_crop(ppp,1);
                I_2_crop_Smth(ppp,1)=-(AmEx_mean_crop(ppp,1))^(1.5)/(sqrt(2*(d_min_Smth_mean_crop(ppp,1)-d_min_Smth_crop (iii+1,1))))*OMEGA_AM_Dif_Smth_crop(ppp,1);
            
                I_1_dis_crop_Smth(ppp,1)=(1+(AmEx_mean_crop(ppp,1))^(0.5)/8/(sqrt(pi*(d_min_Smth_mean_crop(ppp,1)-d_min_Smth_crop (iii+1,1)))))*Fi_Dis_mean_crop(ppp,1)*d_min_Incr_Smth_crop(ppp,1);
                I_2_dis_crop_Smth(ppp,1)=-(AmEx_mean_crop(ppp,1))^(1.5)/(sqrt(2*(d_min_Smth_mean_crop(ppp,1)-d_min_Smth_crop (iii+1,1))))*Fi_Dis_Incr_Smth_crop(ppp,1);
      
                Fts_cons_crop_Smth(iii,1)= Fts_cons_crop_Smth(iii,1)-2*k*(I_1_crop_Smth(ppp,1)+I_2_crop_Smth(ppp,1));
            
                Integral_Fts_dis_crop_Smth(iii,1)=Integral_Fts_dis_crop_Smth(iii,1)+(I_1_dis_crop_Smth(ppp,1)+I_2_dis_crop_Smth(ppp,1));
            end
            
                I_1_crop_raw(ppp,1)=(1+(AmEx_mean_crop(ppp,1))^(0.5)/8/(sqrt(pi*(d_min_mean_crop(ppp,1)-d_min_crop (iii+1,1)))))*OMEGA_AM_mean_crop(ppp,1)*d_min_Incr_crop(ppp,1);
                I_2_crop_raw(ppp,1)=-(AmEx_mean_crop(ppp,1))^(1.5)/(sqrt(2*(d_min_mean_crop(ppp,1)-d_min_crop (iii+1,1))))*OMEGA_AM_Dif_crop(ppp,1);
            
                I_1_dis_crop_raw(ppp,1)=(1+(AmEx_mean_crop(ppp,1))^(0.5)/8/(sqrt(pi*(d_min_mean_crop(ppp,1)-d_min_crop (iii+1,1)))))*Fi_Dis_mean_crop(ppp,1)*d_min_Incr_crop(ppp,1);
                I_2_dis_crop_raw(ppp,1)=-(AmEx_mean_crop(ppp,1))^(1.5)/(sqrt(2*(d_min_mean_crop(ppp,1)-d_min_crop (iii+1,1))))*Fi_Dis_Incr_crop(ppp,1);
      
                Fts_cons_crop_raw(iii,1)= Fts_cons_crop_raw(iii,1)-2*k*(I_1_crop_raw(ppp,1)+I_2_crop_raw(ppp,1));
            
                Integral_Fts_dis_crop_raw(iii,1)=Integral_Fts_dis_crop_raw(iii,1)+(I_1_dis_crop_raw(ppp,1)+I_2_dis_crop_raw(ppp,1));
        end
	 end
     
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%=================== END. SOLVE EQUATION BELOW ============================================================%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    

	%%%% Smoothened%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	
    if Use_smoothening==1   %% this is smoothended
        Fts_dis_Incr_crop=Integral_Fts_dis_crop_Smth(2:end)-Integral_Fts_dis_crop_Smth(1:end-1);  %%% Smooth data
        Fts_dis_crop_Smth=-gamma_medium*(Fts_dis_Incr_crop./d_min_Incr_Smth_crop(1:end-1));  %%%% Smoothened 
    end
    %%%% Raw =====================================================================================================================================%%%%%%%%%%
    Fts_dis_Incr_crop_raw=Integral_Fts_dis_crop_raw(2:end)-Integral_Fts_dis_crop_raw(1:end-1);
    Fts_dis_crop_raw=-gamma_medium*(Fts_dis_Incr_crop_raw./d_min_Incr_crop(2:end));
	
	%%%%%%%%%%%%=================== PLOTTING FORCES ============================================================%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	
	%%%%%%%%=============== CONSERVATIVE FORCE AND DAMPING COEFFICIENT ======================================================%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%% CONSERVATIVE DISSIPATIVE  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

	if Smooth_raw_data==0
		figure (count_figures+11)
		hold on
		plot(d_min_crop,Fts_cons_crop_raw,'.r','Markersize',M_size,'displayname','Conservative force: Sader-Katan:raw'); 
		hold on
		box on
		title('Force Sader and damping coefficient versus zc','fontsize',12)
		xlabel('dmin','fontsize',14) 
		ylabel('Conservative force','fontsize',14); 
		
		%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
			%%%%%%%% Get rid of infs, nans and zeros %%%%%%%%
		DUMMY_YY=zeros(length(Fts_cons_crop_raw));
		DUMMY_XX=zeros(length(d_min_crop));
		DUMMY_YY=Fts_cons_crop_raw;
		DUMMY_XX=d_min_crop;
		GetRidOfNANSINFS; %%% This gets rid of infs, NANS,complex etc, and returns real and numbers only as DUMMY_YY_real and DUMMY_XX_real
		Fts_cons_crop_raw_real=DUMMY_YY_real;
		d_min_crop_real=DUMMY_XX_real;	
		
		%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
		%%% Smoothen %%%%%
 		Fts_cons_crop_ss=smooth(Fts_cons_crop_raw_real,ss_Fts_cons_S_K,'rloess');				%%% This does not Smoothen properly anyway if complex and NANS % What ends us with S is smooth from final curve not smoothed data 		
		plot(d_min_crop_real,Fts_cons_crop_ss,'.b','Markersize',M_size, 'displayname','Conservative force S_K raw: Smooth');	
		Fts_cons_crop_ss_min=min(Fts_cons_crop_ss(floor(0.1*(length(Fts_cons_crop_ss))):floor(0.95*(length(Fts_cons_crop_ss)))));
		F_adhesion=Fts_cons_crop_ss_min;
		
		%%%%% damping %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
		Damping_coefficient_crop_ss=smooth(Damping_coefficient_crop,ss_Damping_Coeff,'rloess');
		plot(d_min_crop,Damping_coefficient_crop,'.k','Markersize',M_size, 'displayname','Damping coefficient raw');
		plot(d_min_crop,Damping_coefficient_crop_ss,'.c','Markersize',M_size, 'displayname','Damping coefficient Smooth');
		Damping_coefficient_crop_ss_max=max(Damping_coefficient_crop_ss(floor(0.1*(length(Damping_coefficient_crop_ss))):floor(0.95*(length(Damping_coefficient_crop_ss)))));
		
		text(0,1.2*abs(F_adhesion), ['Max damping :' num2str(Damping_coefficient_crop_ss_max), ' Ns/m'],'fontsize',12)
		text(0,0.8*abs(F_adhesion), ['F adhesion:' num2str(F_adhesion), ' N'],'fontsize',12)	
		axis([(d_min(end)-1e-9) d_min(1) -abs(1.2*F_adhesion) abs(2*F_adhesion)])
		
	else

	%%%% Needs to be smoothened with decreasing d_min_crop ALSO remove zeros etc.  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%% Figure 11 conservative  and dissipative coefficient Sader-Katan %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	Smoothen_Sader_Katan_Force;   %% This plots conservative damping and integral damping raw and also smoothend
	end
	
	
	%%%% Smoothened processing. PLotting conservative and damping coefficient for smoothened data ======================================%%%%%%%%%%%%%%%%%
	if Use_smoothening==1   %% this is smoothended
       	plot(d_min_Smth_crop,Fts_cons_crop_Smth,'.b','Markersize',4,'displayname','Conservative force smooth');
		Damping_coefficient_crop_Smth=smooth(Damping_coefficient_crop,s_Damping_Coeff,'rloess'); 	
		plot(d_min_Smth_crop,Damping_coefficient_crop_Smth,'.c','Markersize',3,'displayname','Conservative force smooth');
	end
	

	
	%%%%%% VOIGT MODEL ===============================================================================================================%%%%%%%%%%%
% 	if Simulation==1    %%% Sadar Model does not get viscoelasticity as a function of distance it is effective at the point!
% 		Viscoelasticity=zeros(length(d_min_crop),1);
% 		for iii=1:length(d_min_crop)
% 			if d_min_crop(iii)<a0
% 				Viscoelasticity(iii)=eta_c*(R.*abs(d_min_crop(iii)-a0))^(0.5);
% 			end
% 		end
% 		figure (count_figures+11)
% 		hold on
% 		plot(d_min_crop, Viscoelasticity,'Vc','Markersize',3, 'displayname','Damping Voigt Model'); 
% 		figure (count_figures+12)
% 		hold on
% 		plot(d_min_crop, Viscoelasticity,'Vc','Markersize',3, 'displayname','Damping Voigt Model'); 
% 	end
% 	
	%%%%%%%%=============== END CONSERVATIVE FORCE AND DAMPING COEFFICIENT ======================================================%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	
	
	%%%%% integral DISSIPATIVE COEFFICIENT form ======================================================================%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	
	if Smooth_raw_data==0   %%% If 1 everything here is plotted in the Smoothen_Sader_Katan_Force file
		
		figure (count_figures+12)
		hold on
		plot(d_min_crop,Fts_cons_crop_raw,'.r','Markersize',M_size,'displayname','Conservative force: Sader-Katan:raw'); 
		plot(d_min_crop_real,Fts_cons_crop_ss,'.b','Markersize',M_size, 'displayname','Conservative force S_K raw: Smooth');
		plot(d_min_crop(1:end-1),Fts_dis_crop_raw,'.k','Markersize',M_size, 'displayname','Dissipative coefficient: Sader Integral:raw');
		hold on
		box on
		title('Effective Integral coefficient','fontsize',12)
		xlabel('dmin','fontsize',14) 
		ylabel('Dissipative coefficient: Integral','fontsize',14); 
	
		%%% Smooth %%%%%%%
		Fts_dis_crop_raw_s=smooth(Fts_dis_crop_raw,s_Fts_dis_s,'rloess'); %	
		Fts_dis_crop_raw_max=max(Fts_dis_crop_raw_s(floor(0.1*(length(Fts_dis_crop_raw_s))):floor(0.95*(length(Fts_dis_crop_raw_s)))));
		plot(d_min_crop(1:end-1),Fts_dis_crop_raw_s,'.c','Markersize',M_size,'displayname','Dissipative coefficient: Integral_smooth');
	
		
		text(0,0.8*abs(F_adhesion), ['Max Damping:' num2str(Fts_dis_crop_raw_max), ' Ns/m'],'fontsize',12)
		text(0,0.4*abs(F_adhesion), ['F adhesion:' num2str(F_adhesion), ' N'],'fontsize',12)
		axis([(d_min(end)-1e-9) d_min(1) -abs(1.2*F_adhesion) abs(2*F_adhesion)])
		
	
		if Use_smoothening==1   %% this is smoothended
			plot(d_min_Smth_crop(1:end-1),Fts_dis_crop_Smth,'.b','Markersize',4,'displayname','Dissipative coefficient: Integral smooth');
		end
	
	end
    
	
	%%%%% END integral DISSIPATIVE COEFFICIENT form ======================================================================%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	
	
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%% End PLotting conservative and damping coefficient for smoothened data ==========================================================%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	
	
	%%%%%%%%%%%%%%% Save files %%%%%%%%%%%%%%%%
	
		if save_files_Sader_Katan==1    %% save files automatically
			for iii=11:12
			saveas(count_figures+iii, num2str(iii),'fig')	
			end
		end
	
	end %%%% End of Sader Katan method 
	
	
	
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%=================== Analytical stuff such as Energy dissipation, Virial, etc. ============================================================%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   
	if Further_Analysis==1
		
		
		if Smooth_raw_data==1   %%% 
	
			Sorting_dmin_for_Smothening;		%%%	This will be used in the Analytical Analysis file
		
		end
		
		Analytical_analysis;
		
		if save_files_further_analysis==1    %% save files automatically
			for iii=57:78
			saveas(count_figures+iii, num2str(iii),'fig')	
			end
		end
		
	end
	
	
	
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%=================== RAMAN reconstruction below ============================================================%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	
	if Raman==1	
	
		Raman_force;
		
		%%%%%%%%%%%%%%% Save files %%%%%%%%%%%%%%%%
	
		if save_files_Raman==1    %% save files automatically
			for iii=13:14
			saveas(count_figures+iii, num2str(iii),'fig')	
			end
			saveas(count_figures+iii, '40','fig')	
		end
		
	end
	
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%=================== Load simulation forces at the end ============================================================%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	
	if Load_simulation_forces==1
		
		load_sim_forces;
		
	end

	if plot_raw_curves==1
		
		for iii=83:86
			saveas(count_figures+iii, num2str(iii),'fig')	
		end
	end
	
	count_figures=count_figures+100;
	
	save SimulationData;
	
end





