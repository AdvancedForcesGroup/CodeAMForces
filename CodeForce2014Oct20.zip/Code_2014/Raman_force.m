

%%%%%%%%%%%%%%%  Chebyshev POlynomials  %%%%%%%%%%
% clc
% clear all
% close all
%load dondoff.mat
syms x Z Z_Ch Z_norm Z_dis   %%   z is the range of integration whereas Z_Ch is the range of -1 to 1 of Chebyshev polynomials
format longEng
M_size=5;
set(0,'DefaultAxesFontSize',14)  %%% This sets the font size in figures
set(0,'DefaultAxesFontSize',14)  %% axis size figures
set(0,'DefaultAxesLinewidth',2)  %% Lne width figures
box on

%%%% Raman's figures are 40 plus

%%%%%% DEFINITIONS FOR INTEGRATION=================================================================== %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

N_Chebyshev=8;					%%% 30 and 45 are best for continuous hysteresis.   81 bad  45 bad for hysteresis don doff FFT
N_Dmin=N_Chebyshev;
dissipative_force=1;			%%% If 1 then it calculates dissipative force
continuous=1;					%%% If zero it calculates polinomial based on FFT basis. Typically simulation only. 

epsilon=1e-18;					%%% for the first integral that diverges for quadl integration 
epsilon_nm=epsilon*1e9;			%%% epsilon of integration at ato meter
Tolerance_quadl=1e-15;			%% from 1e-11 and smaller to 1e-15 errors in 4th significant figure. This is for the quadl function
Activate_Pick_d_min_Raman=0;	%% If 0 then the chevishev are calculated at a range of dmin automatically, if 1 then you can pick dmin to use for calculation
Activate_crop_Raman=0;

Added_D_max=0;					%% This adds to limit of integration, not used normally
D_m_raman_plot=0.8;				%% Maximum range. Part of the plot (Raman forces) to see. Can be less than 1. Typically 0.3-1
s_F_c_raman=0.15;
s_F_c_raman_dis=0.25;

%%%%%%===============================================================================================================%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%% Sorting dmin to dmax range of points distributed over equal dmin range %%%%%%%%%%%%%%



Raman_flipping_from_D_min_to_D_max;   %  d_min_Raman; AmEx_Raman; cosine_Raman; ZsnrEx_Raman; sine_Raman

if Activate_crop_Raman==1
	Raman_crop_range;					  %% Can be disconnected. Allows cropping further the range of dmin   
end

L=length(d_min_Raman);

D_max=d_min_Raman(1)+Added_D_max;
D_min=d_min_Raman(L);

AmEx_squared_Raman=AmEx_Raman.*AmEx_Raman;

%%%% The one below provides the points at which the chevishev should be computed. POsition Vectors: Position_d_min(ppp)

% if continuous==1  %% This is for experimental data and simualtion which is taken from continuous data. If simulation or FFT, then this is zero 
	Finding_dmin_range;  %% This is better than Distance_in_elements since it chooses range in dmin rather than distance in elements 
% 
% else
% 	FFT_points_Raman;
% 	AmEx_squared_Raman= %%% Here the New Raman stuff
% end

%%%%%%%%%%%% Finding dmin vectors %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% PARAMETERS %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%% Conservative %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
OMEGA_s=OMEGA^2;
Constant_c_raman_1=pi*k/2;
OMEGA_s_minus_one=OMEGA_s-1;
Constant_c_raman_2=A0*((1-OMEGA_s)^2+(OMEGA/Q)^2)^(0.5);




%%% Dissipative %%%%%%%%%%%%%%%%%%

C_dis_1=pi*k/2;
C_dis_2=A0*((1-OMEGA_s)^2+(OMEGA/Q)^2)^(0.5);
C_dis_3=OMEGA/Q;
									  
Diss_vector=C_dis_1*(C_dis_2*(AmEx_Raman.*sine_Raman)- C_dis_3*AmEx_squared_Raman);   % this is  a vector
                                         	

%%%%%%%%%%%%%% ADDD THE SINE AND EVERYTHING ELSE ABOVE FOR DISSIPATIVE %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% TO DOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


Conservative=zeros(N_Chebyshev,1);          %%%% for each dmin
Dissipative=zeros(N_Chebyshev,1);
In=zeros(N_Chebyshev, N_Dmin);				%%%% These are the integrals. ccc is the chevishev  ppp is the given dmin of point in the curve
In_dis=zeros(N_Chebyshev, N_Dmin);			%%% 


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  Calculation of components %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


for ppp=1:1:N_Dmin
	
	%%%%% Conservative %%%%
	
	D_1=d_min_Raman(Position_d_min(ppp)); %+1-ccc);  in meters
	D_1_nm=D_1*1e9;						  %			 in nm 
	Amplitude=AmEx_Raman(Position_d_min(ppp)); %+1-ccc);
	Amplitude_nm=Amplitude*1e9;
	Amplitude_squared=AmEx_squared_Raman(Position_d_min(ppp)); %+1-ccc);
	Amplitude_squared_nm=Amplitude_squared*1e18;
	cosine_angle_r=cosine_Raman(Position_d_min(ppp));

	Conservative(ppp)=-Constant_c_raman_1*Amplitude_squared*(OMEGA_s_minus_one+cosine_angle_r/Amplitude*Constant_c_raman_2);
	
	%%%%% Dissipative %%%%%%%%%%%%%%%%
	Dissipative(ppp)=Diss_vector(Position_d_min(ppp));
	

	if dissipative_force==1
% 		Dissipative(ppp)=
		In_dis(1,ppp)=1-((2*D_1-(D_min+D_max))/(D_max-D_min));
	end
	for ccc=1:1:N_Chebyshev 
		%%%% ccc is the chevishev  ppp is the given dmin of point in the curve
		In(ccc,ppp)=quadl(SolveIntegral_Cons(D_1_nm, D_min, D_max, Amplitude_nm, Amplitude_squared_nm, ccc, epsilon_nm),D_1,D_max, Tolerance_quadl);   %%%% ccc is the chevishev  ppp is the given dmin of point in the curve
		if ccc>1
			In_dis(ccc,ppp)=quadl(SolveIntegral_Dis(ccc, D_min, D_max),D_1,D_max, Tolerance_quadl);
		end
	end

 	ppp
%   In(:,ppp);
% 	In_dis(:,ppp)
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   QR method Dissipative  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if dissipative_force==1
% 	

	A_dis=In_dis';
	X_dis=zeros(N_Dmin,1);
	B_dis=Dissipative;
	
	
	
	[m_dis,n_dis]=size(A_dis);
	[Q_dis, R_dis, P_dis]=qr(A_dis);
	r_dis=rank(A_dis);

	% %% Submatrices %%

	Q1_dis=Q_dis(:,1:r_dis);
	Q2_dis=Q_dis(:,r_dis+1:m_dis);
	R1_dis=R_dis(1:r_dis, 1:r_dis);
	% 
	%% Check if B is in range with A %%
	this_dis=norm(Q2_dis'*B_dis);    %%% if close to zero then method works 

	%%% Solution %%%%

	X_dis=P_dis*[(R1_dis\(Q1_dis'*B_dis)); zeros(n_dis-r_dis,1)];  %these are the chevishev coefficients
	
   solution_dis=norm(A_dis*X_dis-B_dis);   % thi is to verify a solution has been found 
   
   X_dis=double(X_dis);


end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   END QR method Dissipative  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


	
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   QR method Conservative %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 	A_QN=In';
	X_QN=zeros(N_Dmin,1);
	B_QN=Conservative;
	
	
	
	[m,n]=size(A_QN);
	[Q_QN, R_QN, P_QN]=qr(A_QN);
	r_QN=rank(A_QN);

	% %% Submatrices %%

	Q1_QN=Q_QN(:,1:r_QN);
	Q2_QN=Q_QN(:,r_QN+1:m);
	R1_QN=R_QN(1:r_QN, 1:r_QN);
	% 
	%% Check if B is in range with A %%
	this=norm(Q2_QN'*B_QN);    %%% if close to zero then method works 

	%%% Solution %%%%

	X_QN=P_QN*[(R1_QN\(Q1_QN'*B_QN)); zeros(n-r_QN,1)];  %these are the chevishev coefficients
	
   solution=norm(A_QN*X_QN-B_QN);   % thi is to verify a solution has been found 
   
   X_QN=double(X_QN);

 
   %%%%%%%%%%%%%% Polynomial approx %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

		PPP=Z_norm;
		SSS=Z_norm;
		SSS=1;
		
		PPP_dis=Z_dis;
		SSS_dis=Z_dis;
		SSS_dis=1;

		
		if N_Chebyshev==1
			Fts_cons=X_QN(1,1);  %%% This is the first chevishev coefficient
			if dissipative_force==1
				Fts_dis=X_dis(1,1);	
			end
		end
		if N_Chebyshev==2
			Fts_cons=X_QN(1,1)+X_QN(2,1).*Z_norm; 
			if dissipative_force==1
				Fts_dis=X_dis(1,1)+X_dis(2,1).*Z_dis;	
			end
		end
		
		if N_Chebyshev>2
			Fts_cons=X_QN(1,1)+X_QN(2,1).*Z_norm; 
			Fts_cons = expand(Fts_cons);
			if dissipative_force==1
				Fts_dis=X_dis(1,1)+X_dis(2,1).*Z_dis;	
				Fts_dis=expand(Fts_dis);
			end
			for ccc=3:1:N_Chebyshev
				QQQ=2.*Z_norm.*PPP-SSS;
				QQQ = expand(QQQ);
				SSS=PPP;
				PPP=QQQ;
				Fts_cons=Fts_cons+X_QN(ccc,1).*QQQ;
				Fts_cons=expand(Fts_cons);
				Fts_cons=vpa(Fts_cons);
				
				if dissipative_force==1
					QQQ_dis=(2.*Z_dis.*PPP_dis-SSS_dis);
					QQQ_dis=expand(QQQ_dis);
					SSS_dis=PPP_dis;
					PPP_dis=QQQ_dis;
					Fts_dis=Fts_dis+X_dis(ccc,1).*QQQ_dis;
					Fts_dis=expand(Fts_dis);
					Fts_dis=vpa(Fts_dis);

				end
			end
			
		end
		
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% AUTOMATIC ENDS %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%		
%%%%%% PLoting forces 


xxx=-1:0.005:D_m_raman_plot;
% Fts_cons=simplify(Fts_cons);
F_c_raman=subs(Fts_cons, xxx);

range_distances_raman=abs(D_max-D_min)*(1-(1-D_m_raman_plot)/2);

length_raman_xxx=length(xxx);
distaces_raman=D_min:0.0025*abs(D_max-D_min):(D_min+range_distances_raman);
%this=length(distaces_raman)

figure (count_figures+13)   %% Here goes the force 
hold on
box on
plot(distaces_raman, F_c_raman, '.r', 'Markersize', M_size,  'displayname','Conservative Force Raman');
title('Conservative Force Raman','fontsize',12)
xlabel('dmin','fontsize',14) 
ylabel('Force conservative and dissipative Newton','fontsize',14)
F_c_raman_smooth=smooth(F_c_raman,s_F_c_raman,'rloess'); 
plot(distaces_raman, F_c_raman_smooth, '.b', 'Markersize', M_size,  'displayname','Conservative Force Raman: Smooth');
hold on
box on

%%%% Dissipative %%%%%

xxx_dis=-1:0.005:D_m_raman_plot;
F_dis_raman=subs(Fts_dis, xxx_dis);
distaces_raman_dis=distaces_raman;
%figure (count_figures+12)   %% Here goes the force 

plot(distaces_raman_dis, F_dis_raman, '.k', 'Markersize', M_size,  'displayname','Dissipative Force Raman');
F_dis_raman_smooth=smooth(F_dis_raman,s_F_c_raman_dis,'rloess');
box on
hold on
plot(distaces_raman_dis, F_dis_raman_smooth, '.c', 'Markersize', M_size, 'displayname','Dissipative Force Raman: Smooth');

figure (count_figures+14)
hold on
box on
F_raman_total=F_dis_raman + F_c_raman;
plot(distaces_raman_dis, F_raman_total, '.r', 'Markersize', M_size, 'displayname','Total Force Raman');
F_raman_total_smooth=smooth(F_raman_total,s_F_c_raman,'rloess'); 
plot(distaces_raman_dis, F_raman_total_smooth, '.b', 'Markersize', M_size, 'displayname','Total Force Raman: Smooth');
title('Total Force Raman Newtons','fontsize',12)
xlabel('dmin','fontsize',14) 
ylabel('Force: Total','fontsize',14)



