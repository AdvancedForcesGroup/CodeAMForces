

Set_Raman=[d_min_crop, AmEx_crop, cosine_angle_EX_crop, ZsnrEx_crop, sine_angle_EX_crop];
Set_Raman_sorted=sortrows(Set_Raman);
Set_Raman_sorted=flipdim(Set_Raman_sorted,1);
d_min_Raman=Set_Raman_sorted(:,1);
AmEx_Raman=Set_Raman_sorted(:,2);
cosine_Raman=Set_Raman_sorted(:,3);
ZsnrEx_Raman=Set_Raman_sorted(:,4);
sine_Raman=Set_Raman_sorted(:,5);
